package com.dw.emp.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

}
